<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReportControllerCustom;
use Illuminate\Support\Facades\Route;


// Route::middleware('guest')->group(function () {
//     Route::get('/', fn() => view('auth.login'))->name('home');
// });
Route::middleware('guest')->group(function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');
});

Route::middleware('auth')->group(function () {

    // Route admin dan guru
    Route::get('/management/data-pengguna', fn() => view('management'))->name('management');

    // Route Report Unread
    Route::get('report/unread', [ReportControllerCustom::class, 'unreadReport'])->name('report.unreadReport');

    // Report Progressing
    Route::get('report/progressing', [ReportControllerCustom::class, 'progressingReport'])->name('report.progressingReport');

    // Route Report Finish
    Route::get('report/selesai', [ReportControllerCustom::class, 'selesaiReport'])->name('report.selesaiReport');
    
    // Route Report
    Route::resource('report', ReportController::class);
    Route::get('report/{report}/process', [ReportController::class, 'processingReport'])->name('report.processingReport');
    Route::get('report/{report}/finish', [ReportController::class, 'finishReport'])->name('report.finishReport');
    Route::post('report/{report}/comment', [ReportController::class, 'commentReport'])->name('report.commentReport');
});

Route::middleware(['auth', 'verified'])->group(function () {
    
});

require __DIR__ . '/auth.php';
