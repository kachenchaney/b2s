# PROFILE MANAGEMENT
- **Not Delete**
- **Unique email**
- **Unique nomor hp**
- **Unique NIK**
- **Unique nomor bpjs**

# TOKEN QR
- **Konseling**
- **Konseling kating**
- **Kesehatan**

# RECORD KESEHATAN
- **Record Pengajuan Keluhan**
- **Respons Perawat**
  - Record obat *(nullable)*
  - Record rujukan *(nullable)*
  - Respons message
- **Status Record**

# RECORD KONSELING
- 

# RECORD KONSELING KATING
- 